// JavaScript Document

/* =======================================================================================
Short code list ------------------------------------------------------------------------------
	Plugin 1. Multi Lavel Dropdown menu main script
	Plugin 2.
	Plugin 3. Slick js
	Plugin 4. Stellar.js
	Plugin 5. 
	Plugin 6. Stiky header section
==========================================================================================*/


/*==========================================================================================
 Plugin 1. multilavel header menu short script start 
=============================================================================================*/
$(document).ready(function(){
$(".cssmenu").menumaker({ title: "Menu", format: "multitoggle" });
});
/*==========================================================================================
 multilavel header menu short script end here 
=============================================================================================*/


/*==========================================================================================
 Plugin 3. Slick js short script start 
=============================================================================================*/
$(document).ready(function() {
	
	$('.home-slider').slick({
		fade: true,
        dots: false,
        infinite: true,
		arrows: true,
        slidesToShow: 1,
        slidesToScroll: 1
      });
	
      $('.three-item-slider').slick({
        dots: false,
        dots: false,
        infinite: true,
		arrows: true,
        slidesToShow: 3,
        slidesToScroll: 1,
        responsive: [
          {
            breakpoint: 1024,
            settings: {
              slidesToShow: 3,
              slidesToScroll: 1,
            }
          },
          {
            breakpoint: 600,
            settings: {
              slidesToShow: 2,
              slidesToScroll: 1
            }
          },
          {
            breakpoint: 480,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1
            }
          }
          // You can unslick at a given breakpoint now by adding:
          // settings: "unslick"
          // instead of a settings object
        ]
      });
	  
	  
	  
	  
	  
});
/*==========================================================================================
 Slick js short script end here 
=============================================================================================*/



/*==========================================================================================
 Plugin 6. sticky header section short script start 
=============================================================================================*/
$( document ).ready( function( $ ) {
      $('.sticky-section').stickable();
});
/*==========================================================================================
sticky header section short script end here 
=============================================================================================*/

$( document ).ready( function( $ ) {
	$(".collapsButton").click(function(){
	    $(this).closest(".hdrCnnctList").toggleClass("collaped");
	});
});



